<?php
function onecommunity_js_functions_child() {
wp_enqueue_script( 'onecommunity-js-functions-child', get_stylesheet_directory_uri() . '/js/functions.js', true );
}
add_action( 'wp_enqueue_scripts', 'onecommunity_js_functions_child' );
?>