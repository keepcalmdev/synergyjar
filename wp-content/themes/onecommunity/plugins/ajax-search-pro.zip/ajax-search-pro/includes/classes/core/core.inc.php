<?php
if (!defined('ABSPATH')) die('-1');

require_once(ASP_CLASSES_PATH . "core/class-asp-globals.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-ajax.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-actions.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-filters.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-shortcodes.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-init.php");
//require_once(ASP_CLASSES_PATH . "core/class-asp-assets-loader.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-menu.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-dbman.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-instances.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-manager.php");
require_once(ASP_CLASSES_PATH . "core/class-asp-frontfilters.php");